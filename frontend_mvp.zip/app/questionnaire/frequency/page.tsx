'use client'

import { useState, useEffect } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'

export default function Frequency() {
  const [response1, setResponse1] = useState<any>(null)
  const [questionnaireResponse, setQuestionnaireResponse] = useState<any>({})
  const router = useRouter()
  const searchParams = useSearchParams()

  useEffect(() => {
    const responseParam = searchParams.get('response')
    const questionnaireResponseParam = searchParams.get('questionnaireResponse')
    if (responseParam) {
      setResponse1(JSON.parse(decodeURIComponent(responseParam)))
    }
    if (questionnaireResponseParam) {
      setQuestionnaireResponse(JSON.parse(decodeURIComponent(questionnaireResponseParam)))
    }
  }, [searchParams])

  const handleSelection = (value: number) => {
    const updatedResponse = { ...questionnaireResponse, frequency: value }
    router.push('/questionnaire/phlegm?response=' + encodeURIComponent(JSON.stringify(response1)) +
                '&questionnaireResponse=' + encodeURIComponent(JSON.stringify(updatedResponse)))
  }

  const handleBack = () => {
    const updatedResponse = { ...questionnaireResponse, duration: 0 }
    router.push('/questionnaire/duration?response=' + encodeURIComponent(JSON.stringify(response1)) +
                '&questionnaireResponse=' + encodeURIComponent(JSON.stringify(updatedResponse)))
  }

  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24">
      <h1 className="mb-4 text-2xl font-bold">症狀出現嘅頻率係？</h1>
      <div className="space-y-4">
        {[
          { label: '一周六次以上', value: 0 },
          { label: '一周五次', value: 1 },
          { label: '一周四次', value: 2 },
          { label: '一周三次', value: 3 },
          { label: '一周兩次', value: 4 },
          { label: '一周一次', value: 5 },
          { label: '一個月三次', value: 6 },
          { label: '一個月兩次', value: 7 },
          { label: '一個月一次', value: 8 },
          { label: '超過一個月先有一次', value: 9 },
        ].map((option) => (
          <button
            key={option.value}
            onClick={() => handleSelection(option.value)}
            className="w-full p-2 text-white bg-blue-500 rounded hover:bg-blue-600"
          >
            {option.label}
          </button>
        ))}
      </div>
      <button onClick={handleBack} className="mt-4 p-2 text-blue-500 border border-blue-500 rounded hover:bg-blue-100">
        返回上一頁
      </button>
    </main>
  )
}


'use client'

import { useState, useEffect } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { mainApi } from '../../config'

export default function PhlegmThickness() {
  const [response1, setResponse1] = useState<any>(null)
  const [questionnaireResponse, setQuestionnaireResponse] = useState<any>({})
  const router = useRouter()
  const searchParams = useSearchParams()

  useEffect(() => {
    const responseParam = searchParams.get('response')
    const questionnaireResponseParam = searchParams.get('questionnaireResponse')
    if (responseParam) {
      setResponse1(JSON.parse(decodeURIComponent(responseParam)))
    }
    if (questionnaireResponseParam) {
      setQuestionnaireResponse(JSON.parse(decodeURIComponent(questionnaireResponseParam)))
    }
  }, [searchParams])

  const handleSelection = async (value: number) => {
    const updatedResponse = { ...questionnaireResponse, phlegm_thickness: value }
    try {
      const response = await fetch(mainApi + 'api/questionnaire', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ ...response1, questionnaireResponse: updatedResponse }),
      })
      const data = await response.json()
      if ('success' in data) {
        router.push('/success?response=' + encodeURIComponent(JSON.stringify(data)))
      } else if ('error' in data) {
        router.push('/error?error=' + encodeURIComponent(data.error))
      } else if ('message' in data) {
        router.push('/questionnaire2?response=' + encodeURIComponent(JSON.stringify(data)))
      }
    } catch (error) {
      console.error('Error:', error)
      router.push('/error?error=' + encodeURIComponent('An unexpected error occurred'))
    }
  }

  const handleBack = () => {
    const updatedResponse = { ...questionnaireResponse, phlegm_color: 0 }
    router.push('/questionnaire/phlegm-color?response=' + encodeURIComponent(JSON.stringify(response1)) +
                '&questionnaireResponse=' + encodeURIComponent(JSON.stringify(updatedResponse)))
  }

  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24">
      <h1 className="mb-4 text-2xl font-bold">痰嘅濃度係？</h1>
      <div className="space-y-4">
        <button onClick={() => handleSelection(0)} className="w-full p-2 text-white bg-blue-500 rounded hover:bg-blue-600">
          濃
        </button>
        <button onClick={() => handleSelection(1)} className="w-full p-2 text-white bg-blue-500 rounded hover:bg-blue-600">
          淡
        </button>
      </div>
      <button onClick={handleBack} className="mt-4 p-2 text-blue-500 border border-blue-500 rounded hover:bg-blue-100">
        返回上一頁
      </button>
    </main>
  )
}


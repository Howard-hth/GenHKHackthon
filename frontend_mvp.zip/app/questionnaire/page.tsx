'use client'

import { useState, useEffect } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'

export default function Questionnaire() {
  const [response1, setResponse1] = useState<any>(null)
  const [questionnaireResponse, setQuestionnaireResponse] = useState<any>({})
  const router = useRouter()
  const searchParams = useSearchParams()

  useEffect(() => {
    const responseParam = searchParams.get('response')
    if (responseParam) {
      setResponse1(JSON.parse(decodeURIComponent(responseParam)))
    }
  }, [searchParams])

  const handleSelection = (value: number) => {
    setQuestionnaireResponse({ ...questionnaireResponse, diabetes: value })
    router.push('/questionnaire/pregnancy?response=' + encodeURIComponent(JSON.stringify(response1)) +
                '&questionnaireResponse=' + encodeURIComponent(JSON.stringify({ ...questionnaireResponse, diabetes: value })))
  }

  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24">
      <h1 className="mb-4 text-2xl font-bold">你有冇糖尿病？</h1>
      <div className="space-y-4">
        <button onClick={() => handleSelection(0)} className="w-full p-2 text-white bg-blue-500 rounded hover:bg-blue-600">
          無
        </button>
        <button onClick={() => handleSelection(1)} className="w-full p-2 text-white bg-blue-500 rounded hover:bg-blue-600">
          有
        </button>
      </div>
    </main>
  )
}


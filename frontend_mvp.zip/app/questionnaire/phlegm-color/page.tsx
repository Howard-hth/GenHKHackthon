'use client'

import { useState, useEffect } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'

export default function PhlegmColor() {
  const [response1, setResponse1] = useState<any>(null)
  const [questionnaireResponse, setQuestionnaireResponse] = useState<any>({})
  const router = useRouter()
  const searchParams = useSearchParams()

  useEffect(() => {
    const responseParam = searchParams.get('response')
    const questionnaireResponseParam = searchParams.get('questionnaireResponse')
    if (responseParam) {
      setResponse1(JSON.parse(decodeURIComponent(responseParam)))
    }
    if (questionnaireResponseParam) {
      setQuestionnaireResponse(JSON.parse(decodeURIComponent(questionnaireResponseParam)))
    }
  }, [searchParams])

  const handleSelection = (value: number) => {
    const updatedResponse = { ...questionnaireResponse, phlegm_color: value }
    if (value === 2) {
      router.push('/error?error=' + encodeURIComponent("Sorry, 聽到你有咁嘅情況。由於呢個情況比較嚴重，請即刻聯絡999或前往就近嘅醫院以獲得幫助。確保你得到適當嘅治療。"))
    } else {
      router.push('/questionnaire/phlegm-thickness?response=' + encodeURIComponent(JSON.stringify(response1)) +
                  '&questionnaireResponse=' + encodeURIComponent(JSON.stringify(updatedResponse)))
    }
  }

  const handleBack = () => {
    const updatedResponse = { ...questionnaireResponse, phlegm: 0 }
    router.push('/questionnaire/phlegm?response=' + encodeURIComponent(JSON.stringify(response1)) +
                '&questionnaireResponse=' + encodeURIComponent(JSON.stringify(updatedResponse)))
  }

  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24">
      <h1 className="mb-4 text-2xl font-bold">痰嘅顏色係？</h1>
      <div className="space-y-4">
        <button onClick={() => handleSelection(0)} className="w-full p-2 text-white bg-blue-500 rounded hover:bg-blue-600">
          黃色
        </button>
        <button onClick={() => handleSelection(1)} className="w-full p-2 text-white bg-blue-500 rounded hover:bg-blue-600">
          白色
        </button>
        <button onClick={() => handleSelection(1)} className="w-full p-2 text-white bg-blue-500 rounded hover:bg-blue-600">
          透明無色
        </button>
        <button onClick={() => handleSelection(2)} className="w-full p-2 text-white bg-blue-500 rounded hover:bg-blue-600">
          其他顏色
        </button>
      </div>
      <button onClick={handleBack} className="mt-4 p-2 text-blue-500 border border-blue-500 rounded hover:bg-blue-100">
        返回上一頁
      </button>
    </main>
  )
}


'use client'

import { useState, useEffect } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'

export default function Pregnancy() {
  const [response1, setResponse1] = useState<any>(null)
  const [questionnaireResponse, setQuestionnaireResponse] = useState<any>({})
  const router = useRouter()
  const searchParams = useSearchParams()

  useEffect(() => {
    const responseParam = searchParams.get('response')
    const questionnaireResponseParam = searchParams.get('questionnaireResponse')
    if (responseParam) {
      setResponse1(JSON.parse(decodeURIComponent(responseParam)))
    }
    if (questionnaireResponseParam) {
      setQuestionnaireResponse(JSON.parse(decodeURIComponent(questionnaireResponseParam)))
    }
  }, [searchParams])

  const handleSelection = (value: number) => {
    const updatedResponse = { ...questionnaireResponse, pregnancy: value }
    router.push('/questionnaire/duration?response=' + encodeURIComponent(JSON.stringify(response1)) +
                '&questionnaireResponse=' + encodeURIComponent(JSON.stringify(updatedResponse)))
  }

  const handleBack = () => {
    const updatedResponse = { ...questionnaireResponse, diabetes: 0 }
    router.push('/questionnaire?response=' + encodeURIComponent(JSON.stringify(response1)) +
                '&questionnaireResponse=' + encodeURIComponent(JSON.stringify(updatedResponse)))
  }

  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24">
      <h1 className="mb-4 text-2xl font-bold">你有冇懷孕？</h1>
      <div className="space-y-4">
        <button onClick={() => handleSelection(0)} className="w-full p-2 text-white bg-blue-500 rounded hover:bg-blue-600">
          無
        </button>
        <button onClick={() => handleSelection(1)} className="w-full p-2 text-white bg-blue-500 rounded hover:bg-blue-600">
          有
        </button>
      </div>
      <button onClick={handleBack} className="mt-4 p-2 text-blue-500 border border-blue-500 rounded hover:bg-blue-100">
        返回上一頁
      </button>
    </main>
  )
}


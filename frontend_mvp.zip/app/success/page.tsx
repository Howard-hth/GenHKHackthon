'use client'

import { useState, useEffect } from 'react'
import { useSearchParams } from 'next/navigation'
import Image from 'next/image'
import { mainApi } from '../config'

export default function Success() {
  const [finalResponse, setFinalResponse] = useState<any>(null)
  const searchParams = useSearchParams()

  useEffect(() => {
    const fetchFinalResult = async () => {
      const responseParam = searchParams.get('response')
      if (responseParam) {
        const response3 = JSON.parse(decodeURIComponent(responseParam))
        try {
          const response = await fetch(mainApi + 'api/final_result', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(response3),
          })
          const data = await response.json()
          setFinalResponse(data)
        } catch (error) {
          console.error('Error:', error)
        }
      }
    }
    fetchFinalResult()
  }, [searchParams])

  if (!finalResponse) {
    return <div>Loading...</div>
  }

  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24">
      <h1 className="mb-4 text-2xl font-bold">推薦</h1>
      <div className="space-y-8">
        {finalResponse.success.map((item: any, index: number) => (
          <div key={index} className="bg-white p-6 rounded-lg shadow-md">
            <Image src={item.img} alt={item.product} width={200} height={200} className="mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">{item.product}</h2>
            <p className="mb-2">{item.description}</p>
            <p className="text-sm text-gray-600">{item.ingredient}</p>
          </div>
        ))}
      </div>
    </main>
  )
}


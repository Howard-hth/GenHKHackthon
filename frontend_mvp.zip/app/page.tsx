'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { mainApi } from './config'

export default function Home() {
  const [content, setContent] = useState('')
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch(mainApi + 'api/classification', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ content }),
      })
      const data = await response.json()
      if ('list' in data) {
        router.push('/questionnaire?response=' + encodeURIComponent(JSON.stringify(data)))
      } else if ('error' in data) {
        router.push('/error?error=' + encodeURIComponent(data.error))
      }
    } catch (error) {
      console.error('Error:', error)
      router.push('/error?error=' + encodeURIComponent('An unexpected error occurred'))
    }
  }

  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24">
      <h1 className="mb-4 text-2xl font-bold">我係京都念慈庵嘅產品推介大使</h1>
      <p className="mb-4">請問身體有咩不適症狀需要幫手?</p>
      <form onSubmit={handleSubmit} className="w-full max-w-md">
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          className="w-full p-2 mb-4 border rounded"
          rows={4}
        />
        <button type="submit" className="w-full p-2 text-white bg-blue-500 rounded hover:bg-blue-600">
          提交
        </button>
      </form>
    </main>
  )
}


'use client'

import { useState, useEffect } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { mainApi } from '../config'

export default function Questionnaire2() {
  const [response2, setResponse2] = useState<any>(null)
  const router = useRouter()
  const searchParams = useSearchParams()

  useEffect(() => {
    const responseParam = searchParams.get('response')
    if (responseParam) {
      setResponse2(JSON.parse(decodeURIComponent(responseParam)))
    }
  }, [searchParams])

  const handleSelection = async (value: number) => {
    const updatedResponse = { ...response2, answer: value }
    try {
      const response = await fetch(mainApi + 'api/questionnaire2', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updatedResponse),
      })
      const data = await response.json()
      if ('success' in data) {
        router.push('/success?response=' + encodeURIComponent(JSON.stringify(data)))
      } else if ('error' in data) {
        router.push('/error?error=' + encodeURIComponent(data.error))
      }
    } catch (error) {
      console.error('Error:', error)
      router.push('/error?error=' + encodeURIComponent('An unexpected error occurred'))
    }
  }

  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24">
      <h1 className="mb-4 text-2xl font-bold">你最鍾意邊種口味？</h1>
      <div className="space-y-4">
        {[
          { label: '原味', value: 0 },
          { label: '金桔', value: 1 },
          { label: '薄荷', value: 2 },
          { label: '烏梅', value: 3 },
          { label: '蘋果', value: 4 },
          { label: '檸檬草', value: 5 },
        ].map((option) => (
          <button
            key={option.value}
            onClick={() => handleSelection(option.value)}
            className="w-full p-2 text-white bg-blue-500 rounded hover:bg-blue-600"
          >
            {option.label}
          </button>
        ))}
      </div>
    </main>
  )
}


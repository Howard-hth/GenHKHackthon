'use client'

import { useSearchParams } from 'next/navigation'

export default function Error() {
  const searchParams = useSearchParams()
  const error = searchParams.get('error')

  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24">
      <h1 className="mb-4 text-2xl font-bold">錯誤</h1>
      <p className="text-red-500">{error}</p>
    </main>
  )
}

